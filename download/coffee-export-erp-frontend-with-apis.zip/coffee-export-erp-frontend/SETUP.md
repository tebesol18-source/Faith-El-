# Coffee Export ERP — Frontend (with live backend wiring)

## Quick Start
```bash
npm install
npm run dev
# Open http://localhost:3000
```

## Demo Credentials
- **Admin:** admin@coelrodan.com / admin123
- **Seller:** abi@coelrodan.com / seller123

## Live Backend Wiring (6 entities connected)
This version connects to the backend SQLite database.

### API Routes (all read from SQLite):
- GET /api/dashboard — aggregate KPIs, pipeline stages, priorities, activity timeline
- GET /api/leads — 10 real leads + contacts + tags
- GET /api/leads/[id]/history — state transition history
- GET /api/contracts — 2 real contracts joined with leads
- GET /api/inbox — real threads + messages + AI triage
- GET /api/admin — 7 real agents + operators + AI call logs

### Pages wired with live data:
1. Dashboard — KPIs (3 active deals, $650 pipeline), priorities (real lead names), activity timeline (10 real events)
2. Leads — 10 real leads from database
3. Contracts — 2 real contracts with buyer info
4. Inbox — real conversation thread + AI triage
5. Admin System tab — 7 real AI agents, 1 operator, 9 AI call logs

### Pages with mock fallback (backend tables empty):
- Inventory, Samples, Shipments, Compliance, Finance (will auto-switch to live when backend data is seeded)

## Backend Database Location
The API routes look for the SQLite DB at:
1. `../coffee_export/data/coffee_export.db` (relative to project)
2. `coffee_export/data/coffee_export.db` (inside project)
3. `/home/z/my-project/coffee_export/data/coffee_export.db` (absolute fallback)

Edit `getDbPath()` in each route.ts to change the location.
