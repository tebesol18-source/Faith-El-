# Coffee Export ERP — Complete Platform (Final Build)

## Quick Start
```bash
npm install
npm run dev
# Open http://localhost:3000
```

## Start the Agent Supervisor (background)
```bash
node scripts/supervisor.js --interval 10
```

## Demo Credentials
- **Admin:** admin@coelrodan.com / admin123
- **Seller:** abi@coelrodan.com / seller123

## What's Included

### 19 API Routes (all reading from SQLite)
- GET /api/dashboard — aggregate KPIs, pipeline, priorities, activity timeline
- GET /api/leads — real leads + contacts + tags
- GET /api/leads/[id]/history — state transition history
- GET /api/contracts — real contracts joined with leads
- GET /api/inbox — real threads + messages + AI triage
- GET /api/admin — 7 real agents + operators + AI call logs
- GET /api/supervisor — agent health + fault log + supervisor status
- GET /api/approvals — pending agent actions (approval queue)
- POST /api/approvals — approve/reject with feedback capture
- POST /api/agents/research-leads — seller initiates Agent 2 lead research
- POST /api/inventory/upload — seller uploads CSV of coffee lots
- POST /api/agents/[id]/pause — pause an agent (REAL)
- POST /api/agents/[id]/resume — resume an agent (REAL)
- GET /api/finance — transactions derived from contracts
- GET /api/deals — deals derived from leads + contracts
- GET /api/inventory — lots from DB
- GET /api/samples — sample requests from DB
- GET /api/shipments — shipments from DB
- GET /api/compliance — compliance documents per contract
- GET /api/quotes — quotes derived from contracts
- GET /api/market-prices — ICE Coffee C futures + Ethiopian premiums
- GET /api/vessel-tracking — live vessel positions with weather + alerts
- GET /api/analytics — agent performance, pipeline, financial, feedback metrics

### Agent Supervisor (scripts/supervisor.js)
- Runs all 7 agents every 10 seconds
- Monitors agent health (errors, stuck agents, event backlogs)
- Auto-restarts failed agents
- Drafts personalized outreach emails (Agent 3) with:
  - Multi-language support (EN, DE, JA, FR, IT, KO, ZH, AR, TR, RU)
  - VP-based messaging (VP1-VP4)
  - Specific lot recommendations from inventory
  - Tier-based call-to-actions
  - "Why I Recommended This" reasoning panel with confidence score
- Drafts market-aware contracts (Agent 5) with:
  - ICE Coffee C futures pricing
  - Tier-based premiums
  - EU/non-EU incoterm selection
  - Buyer memory integration
- Generates pending actions for seller approval
- Executes approved actions (advances lead states, creates contracts)
- Learns from seller feedback (reject reasons → email adaptation)
- Derives buyer memories from contracts, samples, feedback, inbox, lead data
- Logs all events to supervisor_log table

### Seller Features
- "Research New Leads" button — generates leads for any country (80+ suggestions)
- "Upload Inventory" button — paste CSV to create lots with coops + washing stations
- Approval modal — review AI-drafted emails/contracts with:
  - Full email body preview
  - Contract terms preview with lot breakdown
  - "Why I Recommended This" reasoning panel
  - "What I Know About This Buyer" memory panel
  - "Learning from Your Past Decisions" feedback panel
  - Reject with structured reason + free-text notes
- Market price ticker on Quotes page (ICE Coffee C + Ethiopian premiums)
- Live vessel tracking on Shipments page (positions, weather, alerts)

### Admin Features
- Portfolio overview (6 sellers, commission, risk)
- Sellers table with per-seller deals + commission breakdown
- Commission tab with received/pending visualization
- Risk tab with at-risk sellers and mitigation actions
- Analytics tab with:
  - 4 KPI cards (leads, close rate, email response, AI approval rate)
  - Agent performance table (runs, errors, AI calls, success rate)
  - Pipeline funnel (lead state distribution)
  - Financial summary (revenue, commission, feedback learning)
  - Leads by country + by tier charts
  - System health (event processing, supervisor, compliance)
- System tab with:
  - Supervisor status banner (running/stopped with heartbeat)
  - Agent health cards with working Pause/Resume buttons
  - Supervisor fault log (auto-corrections, warnings, critical)
  - Operators table

### Database Tables Created
- agent_controls — pause state, run counts, error tracking
- supervisor_log — audit trail of all supervisor events
- pending_agent_actions — approval queue for risky agent operations
- agent_feedback — seller decision capture for learning
- buyer_memory — per-lead preferences and history

### Frontend Pages (14 pages, all wired to live data)
1. Login — email-based role detection
2. Dashboard — KPIs, priorities, activity timeline
3. Inbox — real conversation thread + AI triage
4. Leads — real leads + Research New Leads modal
5. Deals — pipeline derived from leads
6. Inventory — real lots + Upload Inventory modal
7. Samples — real sample requests
8. Quotes — real quotes + market price ticker
9. Contracts — real contracts with signature tracking
10. Shipments — real shipments + live vessel tracking
11. Compliance — real compliance documents matrix
12. Finance — transactions derived from contracts
13. AI Coach — priorities, risk radar, opportunities, chat
14. Admin — portfolio, sellers, commission, risk, analytics, system

## Backend Database
SQLite at: ../coffee_export/data/coffee_export.db (or absolute path)
Edit getDbPath() in each route.ts to change location.

## Seed Data
Run: python scripts/seed_data.py
Adds: 6 lots, 5 sample requests, 3 shipments, 16 compliance documents
