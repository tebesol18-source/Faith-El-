# Coffee Export ERP — Complete Frontend + Agent Supervisor

## Quick Start
```bash
npm install
npm run dev
# Open http://localhost:3000
```

## Demo Credentials
- **Admin:** admin@coelrodan.com / admin123
- **Seller:** abi@coelrodan.com / seller123

## Live Backend Wiring (9 API routes)
All pages connect to the backend SQLite database.

### API Routes:
- GET /api/dashboard — aggregate KPIs, pipeline, priorities, activity timeline
- GET /api/leads — 18+ real leads + contacts + tags
- GET /api/leads/[id]/history — state transition history
- GET /api/contracts — real contracts joined with leads
- GET /api/inbox — real threads + messages + AI triage
- GET /api/admin — 7 real agents + operators + AI call logs
- GET /api/supervisor — agent health + fault log + supervisor status
- GET /api/approvals — pending agent actions (approval queue)
- POST /api/approvals — approve/reject pending actions
- POST /api/agents/research-leads — seller initiates Agent 2 lead research
- POST /api/inventory/upload — seller uploads CSV of coffee lots
- POST /api/agents/[id]/pause — pause an agent (REAL)
- POST /api/agents/[id]/resume — resume an agent (REAL)
- GET /api/finance — transactions derived from contracts
- GET /api/deals — deals derived from leads + contracts

### Agent Supervisor
The supervisor (scripts/supervisor.js) runs as a background process:
```bash
node scripts/supervisor.js --interval 10
```
- Runs all 7 agents every 10 seconds
- Monitors agent health (errors, stuck agents, event backlogs)
- Auto-restarts failed agents
- Generates pending actions for risky operations (sends to approval queue)
- Executes approved actions (advances lead states, creates contracts)
- Logs all events to supervisor_log table
- Writes heartbeat every 60 seconds

### Pages wired with live data:
1. Dashboard — KPIs, priorities, activity timeline (all from real data)
2. Leads — real leads + "Research New Leads" button (triggers Agent 2)
3. Deals — pipeline derived from leads + contracts
4. Inbox — real conversation thread + AI triage
5. Finance — transactions derived from contracts
6. Admin — supervisor dashboard with working pause/resume + approval queue

## Backend Database
SQLite at: ../coffee_export/data/coffee_export.db (or absolute path)
Edit getDbPath() in each route.ts to change location.
