# Coffee Export ERP — Frontend

AI-powered ERP platform for Ethiopian coffee exporters. Built with Next.js 16, React 19, TypeScript, and Tailwind CSS 4.

## Quick Start

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Open http://localhost:3000
```

## Demo Credentials

**Admin (Portfolio Manager):**
- Email: `admin@coelrodan.com`
- Password: `admin123`

**Seller (Operator):**
- Email: `abi@coelrodan.com`
- Password: `seller123`

## What's Included

- **Login page** — email-based role detection (no toggle)
- **Seller role** (12 pages): Dashboard, Inbox, Leads, Deals, Inventory, Samples, Quotes, Contracts, Shipments, Compliance, Finance, AI Coach
- **Admin role** (5 tabs): Portfolio, Sellers, Commission, Risk, System

## Tech Stack

- Next.js 16.1.3 (App Router, Turbopack)
- React 19
- TypeScript
- Tailwind CSS 4
- lucide-react (icons)
- shadcn/ui (48 components)

## File Structure

```
├── src/
│   ├── app/
│   │   ├── layout.tsx          # Root layout
│   │   ├── page.tsx            # All 14 pages (~6,500 lines)
│   │   ├── globals.css         # Coffee-brown design system
│   │   └── api/                # API routes
│   ├── components/ui/          # 48 shadcn/ui components
│   ├── hooks/                  # use-mobile, use-toast
│   └── lib/                    # utils.ts, db.ts
├── public/                     # logo.svg, robots.txt
├── package.json
└── ...
```

## Build for Production

```bash
npm run build
npm start
```

## Connecting to Backend

The frontend currently uses mock data. To connect to the Python/SQLAlchemy backend:
1. Replace mock data arrays in `src/app/page.tsx` with API calls
2. Configure backend URL in environment variables
3. Wire authentication to backend `/auth/login` endpoint
4. Replace dual-blind email system mocks with real email service

See backend documentation in the parent project for API endpoints.
