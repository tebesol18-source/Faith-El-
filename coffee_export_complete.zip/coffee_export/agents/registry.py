"""Agent registry — maps agent IDs to their classes."""

from __future__ import annotations

from coffee_export.agents.base import BaseAgent

REGISTRY: dict[str, type[BaseAgent]] = {}


def register_agent(agent_id: str, agent_class: type[BaseAgent]) -> None:
    REGISTRY[agent_id] = agent_class


def get_agent_class(agent_id: str) -> type[BaseAgent] | None:
    return REGISTRY.get(agent_id)


def list_registered_agents() -> list[str]:
    return sorted(REGISTRY.keys())


def create_agent(agent_id: str) -> BaseAgent | None:
    agent_class = get_agent_class(agent_id)
    if agent_class is None:
        return None
    return agent_class()
